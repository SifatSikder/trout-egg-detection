# Trout Eggs 2 > 2024-07-18 3:57pm
https://universe.roboflow.com/trout-egg-phenotyping/trout-eggs-2

Provided by a Roboflow user
License: CC BY 4.0

